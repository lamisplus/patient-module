export const token = (new URLSearchParams(window.location.search)).get("jwt")
export const url = '/api/v1/'

/*
 export const url =  'http://localhost:8282/api/v1/';
 export const  token = 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJndWVzdEBsYW1pc3BsdXMub3JnIiwiYXV0aCI6IlN1cGVyIEFkbWluIiwibmFtZSI6Ikd1ZXN0IEd1ZXN0IiwiZXhwIjoxNjU1NjczODM2fQ._I-j7beuVL644luQJnFiGD5cmVRVMJxw0Cp8X1_I9G8aUHSV-5gBbpyxcHzghgltRHsy9sdABJCLdtuZRir0qQ'
*/
