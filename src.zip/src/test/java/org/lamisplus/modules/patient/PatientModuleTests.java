package org.lamisplus.modules.patient;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientModuleTests {

//	@Test
//	void contextLoads() {
//	}


}
